import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/distribusi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockDistributionController::index
 * @see app/Http/Controllers/StockDistributionController.php:18
 * @route '/distribusi'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/distribusi/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockDistributionController::create
 * @see app/Http/Controllers/StockDistributionController.php:29
 * @route '/distribusi/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\StockDistributionController::store
 * @see app/Http/Controllers/StockDistributionController.php:43
 * @route '/distribusi'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/distribusi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockDistributionController::store
 * @see app/Http/Controllers/StockDistributionController.php:43
 * @route '/distribusi'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::store
 * @see app/Http/Controllers/StockDistributionController.php:43
 * @route '/distribusi'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::store
 * @see app/Http/Controllers/StockDistributionController.php:43
 * @route '/distribusi'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::store
 * @see app/Http/Controllers/StockDistributionController.php:43
 * @route '/distribusi'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\StockDistributionController::update
 * @see app/Http/Controllers/StockDistributionController.php:117
 * @route '/distribusi/{distribution}'
 */
export const update = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/distribusi/{distribution}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StockDistributionController::update
 * @see app/Http/Controllers/StockDistributionController.php:117
 * @route '/distribusi/{distribution}'
 */
update.url = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { distribution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { distribution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    distribution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        distribution: typeof args.distribution === 'object'
                ? args.distribution.id
                : args.distribution,
                }

    return update.definition.url
            .replace('{distribution}', parsedArgs.distribution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::update
 * @see app/Http/Controllers/StockDistributionController.php:117
 * @route '/distribusi/{distribution}'
 */
update.put = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::update
 * @see app/Http/Controllers/StockDistributionController.php:117
 * @route '/distribusi/{distribution}'
 */
    const updateForm = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::update
 * @see app/Http/Controllers/StockDistributionController.php:117
 * @route '/distribusi/{distribution}'
 */
        updateForm.put = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
export const show = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/distribusi/{distribution}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
show.url = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { distribution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { distribution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    distribution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        distribution: typeof args.distribution === 'object'
                ? args.distribution.id
                : args.distribution,
                }

    return show.definition.url
            .replace('{distribution}', parsedArgs.distribution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
show.get = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
show.head = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
    const showForm = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
        showForm.get = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockDistributionController::show
 * @see app/Http/Controllers/StockDistributionController.php:107
 * @route '/distribusi/{distribution}'
 */
        showForm.head = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StockDistributionController::cancel
 * @see app/Http/Controllers/StockDistributionController.php:179
 * @route '/distribusi/{distribution}/cancel'
 */
export const cancel = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

cancel.definition = {
    methods: ["patch"],
    url: '/distribusi/{distribution}/cancel',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\StockDistributionController::cancel
 * @see app/Http/Controllers/StockDistributionController.php:179
 * @route '/distribusi/{distribution}/cancel'
 */
cancel.url = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { distribution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { distribution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    distribution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        distribution: typeof args.distribution === 'object'
                ? args.distribution.id
                : args.distribution,
                }

    return cancel.definition.url
            .replace('{distribution}', parsedArgs.distribution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockDistributionController::cancel
 * @see app/Http/Controllers/StockDistributionController.php:179
 * @route '/distribusi/{distribution}/cancel'
 */
cancel.patch = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\StockDistributionController::cancel
 * @see app/Http/Controllers/StockDistributionController.php:179
 * @route '/distribusi/{distribution}/cancel'
 */
    const cancelForm = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockDistributionController::cancel
 * @see app/Http/Controllers/StockDistributionController.php:179
 * @route '/distribusi/{distribution}/cancel'
 */
        cancelForm.patch = (args: { distribution: number | { id: number } } | [distribution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    cancel.form = cancelForm
const distribusi = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
update: Object.assign(update, update),
show: Object.assign(show, show),
cancel: Object.assign(cancel, cancel),
}

export default distribusi