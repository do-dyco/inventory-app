import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pendapatan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyIncomeController::index
 * @see app/Http/Controllers/DailyIncomeController.php:13
 * @route '/pendapatan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DailyIncomeController::store
 * @see app/Http/Controllers/DailyIncomeController.php:32
 * @route '/pendapatan'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pendapatan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DailyIncomeController::store
 * @see app/Http/Controllers/DailyIncomeController.php:32
 * @route '/pendapatan'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyIncomeController::store
 * @see app/Http/Controllers/DailyIncomeController.php:32
 * @route '/pendapatan'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DailyIncomeController::store
 * @see app/Http/Controllers/DailyIncomeController.php:32
 * @route '/pendapatan'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyIncomeController::store
 * @see app/Http/Controllers/DailyIncomeController.php:32
 * @route '/pendapatan'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DailyIncomeController::storeBatch
 * @see app/Http/Controllers/DailyIncomeController.php:58
 * @route '/pendapatan/batch'
 */
export const storeBatch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBatch.url(options),
    method: 'post',
})

storeBatch.definition = {
    methods: ["post"],
    url: '/pendapatan/batch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DailyIncomeController::storeBatch
 * @see app/Http/Controllers/DailyIncomeController.php:58
 * @route '/pendapatan/batch'
 */
storeBatch.url = (options?: RouteQueryOptions) => {
    return storeBatch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyIncomeController::storeBatch
 * @see app/Http/Controllers/DailyIncomeController.php:58
 * @route '/pendapatan/batch'
 */
storeBatch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBatch.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DailyIncomeController::storeBatch
 * @see app/Http/Controllers/DailyIncomeController.php:58
 * @route '/pendapatan/batch'
 */
    const storeBatchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBatch.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyIncomeController::storeBatch
 * @see app/Http/Controllers/DailyIncomeController.php:58
 * @route '/pendapatan/batch'
 */
        storeBatchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBatch.url(options),
            method: 'post',
        })
    
    storeBatch.form = storeBatchForm
/**
* @see \App\Http\Controllers\DailyIncomeController::update
 * @see app/Http/Controllers/DailyIncomeController.php:94
 * @route '/pendapatan/{dailyIncome}'
 */
export const update = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/pendapatan/{dailyIncome}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DailyIncomeController::update
 * @see app/Http/Controllers/DailyIncomeController.php:94
 * @route '/pendapatan/{dailyIncome}'
 */
update.url = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dailyIncome: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { dailyIncome: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    dailyIncome: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dailyIncome: typeof args.dailyIncome === 'object'
                ? args.dailyIncome.id
                : args.dailyIncome,
                }

    return update.definition.url
            .replace('{dailyIncome}', parsedArgs.dailyIncome.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyIncomeController::update
 * @see app/Http/Controllers/DailyIncomeController.php:94
 * @route '/pendapatan/{dailyIncome}'
 */
update.put = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DailyIncomeController::update
 * @see app/Http/Controllers/DailyIncomeController.php:94
 * @route '/pendapatan/{dailyIncome}'
 */
    const updateForm = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyIncomeController::update
 * @see app/Http/Controllers/DailyIncomeController.php:94
 * @route '/pendapatan/{dailyIncome}'
 */
        updateForm.put = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DailyIncomeController::destroy
 * @see app/Http/Controllers/DailyIncomeController.php:117
 * @route '/pendapatan/{dailyIncome}'
 */
export const destroy = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pendapatan/{dailyIncome}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DailyIncomeController::destroy
 * @see app/Http/Controllers/DailyIncomeController.php:117
 * @route '/pendapatan/{dailyIncome}'
 */
destroy.url = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dailyIncome: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { dailyIncome: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    dailyIncome: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dailyIncome: typeof args.dailyIncome === 'object'
                ? args.dailyIncome.id
                : args.dailyIncome,
                }

    return destroy.definition.url
            .replace('{dailyIncome}', parsedArgs.dailyIncome.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyIncomeController::destroy
 * @see app/Http/Controllers/DailyIncomeController.php:117
 * @route '/pendapatan/{dailyIncome}'
 */
destroy.delete = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DailyIncomeController::destroy
 * @see app/Http/Controllers/DailyIncomeController.php:117
 * @route '/pendapatan/{dailyIncome}'
 */
    const destroyForm = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyIncomeController::destroy
 * @see app/Http/Controllers/DailyIncomeController.php:117
 * @route '/pendapatan/{dailyIncome}'
 */
        destroyForm.delete = (args: { dailyIncome: number | { id: number } } | [dailyIncome: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const pendapatan = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
storeBatch: Object.assign(storeBatch, storeBatch),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default pendapatan