import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stok',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StockController::initial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
export const initial = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initial.url(options),
    method: 'post',
})

initial.definition = {
    methods: ["post"],
    url: '/stok/initial',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::initial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
initial.url = (options?: RouteQueryOptions) => {
    return initial.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::initial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
initial.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initial.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::initial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
    const initialForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: initial.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::initial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
        initialForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: initial.url(options),
            method: 'post',
        })
    
    initial.form = initialForm
/**
* @see \App\Http\Controllers\StockController::inMethod
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
export const inMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: inMethod.url(options),
    method: 'post',
})

inMethod.definition = {
    methods: ["post"],
    url: '/stok/in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::inMethod
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
inMethod.url = (options?: RouteQueryOptions) => {
    return inMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::inMethod
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
inMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: inMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::inMethod
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
    const inMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: inMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::inMethod
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
        inMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: inMethod.url(options),
            method: 'post',
        })
    
    inMethod.form = inMethodForm
/**
* @see \App\Http\Controllers\StockController::batch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
export const batch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: batch.url(options),
    method: 'post',
})

batch.definition = {
    methods: ["post"],
    url: '/stok/batch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::batch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
batch.url = (options?: RouteQueryOptions) => {
    return batch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::batch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
batch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: batch.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::batch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
    const batchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: batch.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::batch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
        batchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: batch.url(options),
            method: 'post',
        })
    
    batch.form = batchForm
/**
* @see \App\Http\Controllers\StockController::adjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
export const adjustment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustment.url(options),
    method: 'post',
})

adjustment.definition = {
    methods: ["post"],
    url: '/stok/adjustment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::adjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
adjustment.url = (options?: RouteQueryOptions) => {
    return adjustment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::adjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
adjustment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::adjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
    const adjustmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::adjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
        adjustmentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustment.url(options),
            method: 'post',
        })
    
    adjustment.form = adjustmentForm
const stok = {
    index: Object.assign(index, index),
initial: Object.assign(initial, initial),
in: Object.assign(inMethod, inMethod),
batch: Object.assign(batch, batch),
adjustment: Object.assign(adjustment, adjustment),
}

export default stok