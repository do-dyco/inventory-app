import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pengembalian',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockReturnController::index
 * @see app/Http/Controllers/StockReturnController.php:17
 * @route '/pengembalian'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/pengembalian/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockReturnController::create
 * @see app/Http/Controllers/StockReturnController.php:39
 * @route '/pengembalian/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
export const show = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pengembalian/{return}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
show.url = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { return: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { return: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    return: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        return: typeof args.return === 'object'
                ? args.return.id
                : args.return,
                }

    return show.definition.url
            .replace('{return}', parsedArgs.return.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
show.get = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
show.head = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
    const showForm = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
        showForm.get = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockReturnController::show
 * @see app/Http/Controllers/StockReturnController.php:29
 * @route '/pengembalian/{return}'
 */
        showForm.head = (args: { return: number | { id: number } } | [returnParam: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StockReturnController::store
 * @see app/Http/Controllers/StockReturnController.php:50
 * @route '/pengembalian'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pengembalian',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockReturnController::store
 * @see app/Http/Controllers/StockReturnController.php:50
 * @route '/pengembalian'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockReturnController::store
 * @see app/Http/Controllers/StockReturnController.php:50
 * @route '/pengembalian'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockReturnController::store
 * @see app/Http/Controllers/StockReturnController.php:50
 * @route '/pengembalian'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockReturnController::store
 * @see app/Http/Controllers/StockReturnController.php:50
 * @route '/pengembalian'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const pengembalian = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
show: Object.assign(show, show),
store: Object.assign(store, store),
}

export default pengembalian