import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\StockOpnameController::update
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
export const update = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/opname/{opname}/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StockOpnameController::update
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
update.url = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    opname: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        opname: typeof args.opname === 'object'
                ? args.opname.id
                : args.opname,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return update.definition.url
            .replace('{opname}', parsedArgs.opname.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::update
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
update.put = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::update
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
    const updateForm = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::update
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
        updateForm.put = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const items = {
    update: Object.assign(update, update),
}

export default items