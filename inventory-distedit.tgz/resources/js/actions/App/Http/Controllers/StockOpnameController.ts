import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/opname',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockOpnameController::index
 * @see app/Http/Controllers/StockOpnameController.php:15
 * @route '/opname'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StockOpnameController::create
 * @see app/Http/Controllers/StockOpnameController.php:25
 * @route '/opname'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

create.definition = {
    methods: ["post"],
    url: '/opname',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockOpnameController::create
 * @see app/Http/Controllers/StockOpnameController.php:25
 * @route '/opname'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::create
 * @see app/Http/Controllers/StockOpnameController.php:25
 * @route '/opname'
 */
create.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::create
 * @see app/Http/Controllers/StockOpnameController.php:25
 * @route '/opname'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: create.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::create
 * @see app/Http/Controllers/StockOpnameController.php:25
 * @route '/opname'
 */
        createForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: create.url(options),
            method: 'post',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
export const show = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/opname/{opname}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
show.url = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opname: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { opname: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    opname: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        opname: typeof args.opname === 'object'
                ? args.opname.id
                : args.opname,
                }

    return show.definition.url
            .replace('{opname}', parsedArgs.opname.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
show.get = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
show.head = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
    const showForm = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
        showForm.get = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockOpnameController::show
 * @see app/Http/Controllers/StockOpnameController.php:60
 * @route '/opname/{opname}'
 */
        showForm.head = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StockOpnameController::updateItem
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
export const updateItem = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

updateItem.definition = {
    methods: ["put"],
    url: '/opname/{opname}/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StockOpnameController::updateItem
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
updateItem.url = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    opname: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        opname: typeof args.opname === 'object'
                ? args.opname.id
                : args.opname,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return updateItem.definition.url
            .replace('{opname}', parsedArgs.opname.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::updateItem
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
updateItem.put = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::updateItem
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
    const updateItemForm = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateItem.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::updateItem
 * @see app/Http/Controllers/StockOpnameController.php:67
 * @route '/opname/{opname}/items/{item}'
 */
        updateItemForm.put = (args: { opname: number | { id: number }, item: number | { id: number } } | [opname: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateItem.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateItem.form = updateItemForm
/**
* @see \App\Http\Controllers\StockOpnameController::post
 * @see app/Http/Controllers/StockOpnameController.php:83
 * @route '/opname/{opname}/post'
 */
export const post = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: post.url(args, options),
    method: 'patch',
})

post.definition = {
    methods: ["patch"],
    url: '/opname/{opname}/post',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\StockOpnameController::post
 * @see app/Http/Controllers/StockOpnameController.php:83
 * @route '/opname/{opname}/post'
 */
post.url = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opname: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { opname: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    opname: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        opname: typeof args.opname === 'object'
                ? args.opname.id
                : args.opname,
                }

    return post.definition.url
            .replace('{opname}', parsedArgs.opname.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::post
 * @see app/Http/Controllers/StockOpnameController.php:83
 * @route '/opname/{opname}/post'
 */
post.patch = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: post.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::post
 * @see app/Http/Controllers/StockOpnameController.php:83
 * @route '/opname/{opname}/post'
 */
    const postForm = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: post.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::post
 * @see app/Http/Controllers/StockOpnameController.php:83
 * @route '/opname/{opname}/post'
 */
        postForm.patch = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: post.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    post.form = postForm
/**
* @see \App\Http\Controllers\StockOpnameController::cancel
 * @see app/Http/Controllers/StockOpnameController.php:125
 * @route '/opname/{opname}/cancel'
 */
export const cancel = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

cancel.definition = {
    methods: ["patch"],
    url: '/opname/{opname}/cancel',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\StockOpnameController::cancel
 * @see app/Http/Controllers/StockOpnameController.php:125
 * @route '/opname/{opname}/cancel'
 */
cancel.url = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opname: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { opname: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    opname: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        opname: typeof args.opname === 'object'
                ? args.opname.id
                : args.opname,
                }

    return cancel.definition.url
            .replace('{opname}', parsedArgs.opname.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockOpnameController::cancel
 * @see app/Http/Controllers/StockOpnameController.php:125
 * @route '/opname/{opname}/cancel'
 */
cancel.patch = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\StockOpnameController::cancel
 * @see app/Http/Controllers/StockOpnameController.php:125
 * @route '/opname/{opname}/cancel'
 */
    const cancelForm = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockOpnameController::cancel
 * @see app/Http/Controllers/StockOpnameController.php:125
 * @route '/opname/{opname}/cancel'
 */
        cancelForm.patch = (args: { opname: number | { id: number } } | [opname: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    cancel.form = cancelForm
const StockOpnameController = { index, create, show, updateItem, post, cancel }

export default StockOpnameController