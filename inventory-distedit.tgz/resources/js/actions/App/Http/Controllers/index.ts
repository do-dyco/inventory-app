import DashboardController from './DashboardController'
import DailyIncomeController from './DailyIncomeController'
import StockDistributionController from './StockDistributionController'
import StockReturnController from './StockReturnController'
import BranchController from './BranchController'
import MenuItemController from './MenuItemController'
import UserController from './UserController'
import UnitController from './UnitController'
import ProductController from './ProductController'
import StockController from './StockController'
import StockOpnameController from './StockOpnameController'
import ReportController from './ReportController'
import ActivityLogController from './ActivityLogController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
DailyIncomeController: Object.assign(DailyIncomeController, DailyIncomeController),
StockDistributionController: Object.assign(StockDistributionController, StockDistributionController),
StockReturnController: Object.assign(StockReturnController, StockReturnController),
BranchController: Object.assign(BranchController, BranchController),
MenuItemController: Object.assign(MenuItemController, MenuItemController),
UserController: Object.assign(UserController, UserController),
UnitController: Object.assign(UnitController, UnitController),
ProductController: Object.assign(ProductController, ProductController),
StockController: Object.assign(StockController, StockController),
StockOpnameController: Object.assign(StockOpnameController, StockOpnameController),
ReportController: Object.assign(ReportController, ReportController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers