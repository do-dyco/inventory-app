import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/menu',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MenuItemController::index
 * @see app/Http/Controllers/MenuItemController.php:11
 * @route '/menu'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MenuItemController::store
 * @see app/Http/Controllers/MenuItemController.php:18
 * @route '/menu'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/menu',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MenuItemController::store
 * @see app/Http/Controllers/MenuItemController.php:18
 * @route '/menu'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuItemController::store
 * @see app/Http/Controllers/MenuItemController.php:18
 * @route '/menu'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MenuItemController::store
 * @see app/Http/Controllers/MenuItemController.php:18
 * @route '/menu'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MenuItemController::store
 * @see app/Http/Controllers/MenuItemController.php:18
 * @route '/menu'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MenuItemController::update
 * @see app/Http/Controllers/MenuItemController.php:32
 * @route '/menu/{menuItem}'
 */
export const update = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/menu/{menuItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MenuItemController::update
 * @see app/Http/Controllers/MenuItemController.php:32
 * @route '/menu/{menuItem}'
 */
update.url = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { menuItem: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { menuItem: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    menuItem: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        menuItem: typeof args.menuItem === 'object'
                ? args.menuItem.id
                : args.menuItem,
                }

    return update.definition.url
            .replace('{menuItem}', parsedArgs.menuItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuItemController::update
 * @see app/Http/Controllers/MenuItemController.php:32
 * @route '/menu/{menuItem}'
 */
update.put = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MenuItemController::update
 * @see app/Http/Controllers/MenuItemController.php:32
 * @route '/menu/{menuItem}'
 */
    const updateForm = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MenuItemController::update
 * @see app/Http/Controllers/MenuItemController.php:32
 * @route '/menu/{menuItem}'
 */
        updateForm.put = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MenuItemController::toggleActive
 * @see app/Http/Controllers/MenuItemController.php:46
 * @route '/menu/{menuItem}/toggle'
 */
export const toggleActive = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleActive.url(args, options),
    method: 'patch',
})

toggleActive.definition = {
    methods: ["patch"],
    url: '/menu/{menuItem}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\MenuItemController::toggleActive
 * @see app/Http/Controllers/MenuItemController.php:46
 * @route '/menu/{menuItem}/toggle'
 */
toggleActive.url = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { menuItem: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { menuItem: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    menuItem: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        menuItem: typeof args.menuItem === 'object'
                ? args.menuItem.id
                : args.menuItem,
                }

    return toggleActive.definition.url
            .replace('{menuItem}', parsedArgs.menuItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuItemController::toggleActive
 * @see app/Http/Controllers/MenuItemController.php:46
 * @route '/menu/{menuItem}/toggle'
 */
toggleActive.patch = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleActive.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\MenuItemController::toggleActive
 * @see app/Http/Controllers/MenuItemController.php:46
 * @route '/menu/{menuItem}/toggle'
 */
    const toggleActiveForm = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleActive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MenuItemController::toggleActive
 * @see app/Http/Controllers/MenuItemController.php:46
 * @route '/menu/{menuItem}/toggle'
 */
        toggleActiveForm.patch = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleActive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleActive.form = toggleActiveForm
const MenuItemController = { index, store, update, toggleActive }

export default MenuItemController