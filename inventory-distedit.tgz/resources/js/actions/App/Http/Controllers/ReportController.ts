import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
export const stock = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stock.url(options),
    method: 'get',
})

stock.definition = {
    methods: ["get","head"],
    url: '/laporan/stok',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
stock.url = (options?: RouteQueryOptions) => {
    return stock.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
stock.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stock.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
stock.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stock.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
    const stockForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stock.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
        stockForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stock.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::stock
 * @see app/Http/Controllers/ReportController.php:62
 * @route '/laporan/stok'
 */
        stockForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stock.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stock.form = stockForm
/**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
export const opname = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: opname.url(options),
    method: 'get',
})

opname.definition = {
    methods: ["get","head"],
    url: '/laporan/opname',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
opname.url = (options?: RouteQueryOptions) => {
    return opname.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
opname.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: opname.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
opname.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: opname.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
    const opnameForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: opname.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
        opnameForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: opname.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::opname
 * @see app/Http/Controllers/ReportController.php:87
 * @route '/laporan/opname'
 */
        opnameForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: opname.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    opname.form = opnameForm
/**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
export const distribusi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: distribusi.url(options),
    method: 'get',
})

distribusi.definition = {
    methods: ["get","head"],
    url: '/laporan/distribusi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
distribusi.url = (options?: RouteQueryOptions) => {
    return distribusi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
distribusi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: distribusi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
distribusi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: distribusi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
    const distribusiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: distribusi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
        distribusiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: distribusi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::distribusi
 * @see app/Http/Controllers/ReportController.php:110
 * @route '/laporan/distribusi'
 */
        distribusiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: distribusi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    distribusi.form = distribusiForm
/**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
export const pendapatan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendapatan.url(options),
    method: 'get',
})

pendapatan.definition = {
    methods: ["get","head"],
    url: '/laporan/pendapatan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
pendapatan.url = (options?: RouteQueryOptions) => {
    return pendapatan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
pendapatan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendapatan.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
pendapatan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendapatan.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
    const pendapatanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pendapatan.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
        pendapatanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pendapatan.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::pendapatan
 * @see app/Http/Controllers/ReportController.php:132
 * @route '/laporan/pendapatan'
 */
        pendapatanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pendapatan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pendapatan.form = pendapatanForm
/**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
export const pengembalian = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pengembalian.url(options),
    method: 'get',
})

pengembalian.definition = {
    methods: ["get","head"],
    url: '/laporan/pengembalian',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
pengembalian.url = (options?: RouteQueryOptions) => {
    return pengembalian.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
pengembalian.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pengembalian.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
pengembalian.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pengembalian.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
    const pengembalianForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pengembalian.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
        pengembalianForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pengembalian.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::pengembalian
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/laporan/pengembalian'
 */
        pengembalianForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pengembalian.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pengembalian.form = pengembalianForm
const ReportController = { stock, opname, distribusi, pendapatan, pengembalian }

export default ReportController