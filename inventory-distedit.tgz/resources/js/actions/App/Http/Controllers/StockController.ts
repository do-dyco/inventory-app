import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stok',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StockController::index
 * @see app/Http/Controllers/StockController.php:14
 * @route '/stok'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StockController::storeInitial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
export const storeInitial = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInitial.url(options),
    method: 'post',
})

storeInitial.definition = {
    methods: ["post"],
    url: '/stok/initial',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::storeInitial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
storeInitial.url = (options?: RouteQueryOptions) => {
    return storeInitial.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::storeInitial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
storeInitial.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInitial.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::storeInitial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
    const storeInitialForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeInitial.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::storeInitial
 * @see app/Http/Controllers/StockController.php:31
 * @route '/stok/initial'
 */
        storeInitialForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeInitial.url(options),
            method: 'post',
        })
    
    storeInitial.form = storeInitialForm
/**
* @see \App\Http\Controllers\StockController::storeIn
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
export const storeIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeIn.url(options),
    method: 'post',
})

storeIn.definition = {
    methods: ["post"],
    url: '/stok/in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::storeIn
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
storeIn.url = (options?: RouteQueryOptions) => {
    return storeIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::storeIn
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
storeIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::storeIn
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
    const storeInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::storeIn
 * @see app/Http/Controllers/StockController.php:44
 * @route '/stok/in'
 */
        storeInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeIn.url(options),
            method: 'post',
        })
    
    storeIn.form = storeInForm
/**
* @see \App\Http\Controllers\StockController::storeBatch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
export const storeBatch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBatch.url(options),
    method: 'post',
})

storeBatch.definition = {
    methods: ["post"],
    url: '/stok/batch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::storeBatch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
storeBatch.url = (options?: RouteQueryOptions) => {
    return storeBatch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::storeBatch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
storeBatch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBatch.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::storeBatch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
    const storeBatchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBatch.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::storeBatch
 * @see app/Http/Controllers/StockController.php:57
 * @route '/stok/batch'
 */
        storeBatchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBatch.url(options),
            method: 'post',
        })
    
    storeBatch.form = storeBatchForm
/**
* @see \App\Http\Controllers\StockController::storeAdjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
export const storeAdjustment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAdjustment.url(options),
    method: 'post',
})

storeAdjustment.definition = {
    methods: ["post"],
    url: '/stok/adjustment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockController::storeAdjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
storeAdjustment.url = (options?: RouteQueryOptions) => {
    return storeAdjustment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockController::storeAdjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
storeAdjustment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAdjustment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StockController::storeAdjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
    const storeAdjustmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAdjustment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StockController::storeAdjustment
 * @see app/Http/Controllers/StockController.php:98
 * @route '/stok/adjustment'
 */
        storeAdjustmentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAdjustment.url(options),
            method: 'post',
        })
    
    storeAdjustment.form = storeAdjustmentForm
const StockController = { index, storeInitial, storeIn, storeBatch, storeAdjustment }

export default StockController